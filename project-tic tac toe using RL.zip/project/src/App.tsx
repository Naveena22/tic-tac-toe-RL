import React, { useState, useEffect } from 'react';
import { Brain } from 'lucide-react';
import { Board } from './components/Board';
import { QLearningAgent } from './utils/qLearning';
import { calculateWinner, isBoardFull } from './utils/gameLogic';

const agent = new QLearningAgent();

// Try to load saved state from localStorage
const savedState = localStorage.getItem('tictactoe-qlearning-state');
if (savedState) {
  agent.loadState(savedState);
}

function App() {
  const [squares, setSquares] = useState<string[]>(Array(9).fill(''));
  const [xIsNext, setXIsNext] = useState(true);
  const [gameCount, setGameCount] = useState(0);
  const [aiEnabled, setAiEnabled] = useState(true);
  const [status, setStatus] = useState('');

  const { winner, line } = calculateWinner(squares);

  useEffect(() => {
    if (winner) {
      setStatus(`Winner: ${winner}`);
      // Update Q-learning agent
      const reward = winner === 'O' ? 1 : -1;
      agent.learn(squares.join(''), -1, reward, Array(9).fill(''));
      localStorage.setItem('tictactoe-qlearning-state', agent.saveState());
    } else if (isBoardFull(squares)) {
      setStatus('Draw!');
      agent.learn(squares.join(''), -1, 0.5, Array(9).fill(''));
      localStorage.setItem('tictactoe-qlearning-state', agent.saveState());
    } else {
      setStatus(`Next player: ${xIsNext ? 'X' : 'O'}`);
    }
  }, [squares, winner, xIsNext]);

  useEffect(() => {
    if (!xIsNext && aiEnabled && !winner && !isBoardFull(squares)) {
      // AI's turn
      setTimeout(() => {
        const move = agent.chooseAction(squares);
        handleClick(move);
      }, 500);
    }
  }, [xIsNext, aiEnabled, winner, squares]);

  const handleClick = (i: number) => {
    if (squares[i] || calculateWinner(squares).winner) return;

    const newSquares = squares.slice();
    newSquares[i] = xIsNext ? 'X' : 'O';
    setSquares(newSquares);
    setXIsNext(!xIsNext);
  };

  const resetGame = () => {
    setSquares(Array(9).fill(''));
    setXIsNext(true);
    setGameCount(c => c + 1);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
      <div className="bg-white p-8 rounded-lg shadow-lg">
        <div className="flex items-center justify-center gap-2 mb-6">
          <Brain className="w-8 h-8 text-blue-500" />
          <h1 className="text-3xl font-bold text-gray-800">Tic Tac Toe AI</h1>
        </div>

        <div className="mb-6 text-center">
          <p className="text-lg font-semibold text-gray-700 mb-2">{status}</p>
          <p className="text-sm text-gray-600">Games played: {gameCount}</p>
        </div>

        <div className="flex justify-center mb-6">
          <Board squares={squares} onClick={handleClick} winningLine={line} />
        </div>

        <div className="flex gap-4 justify-center">
          <button
            onClick={resetGame}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
          >
            New Game
          </button>
          <button
            onClick={() => setAiEnabled(!aiEnabled)}
            className={`px-4 py-2 ${
              aiEnabled ? 'bg-green-500 hover:bg-green-600' : 'bg-gray-500 hover:bg-gray-600'
            } text-white rounded-lg transition-colors`}
          >
            AI: {aiEnabled ? 'On' : 'Off'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;