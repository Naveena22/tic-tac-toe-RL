import React from 'react';
import { Square } from './Square';

interface BoardProps {
  squares: string[];
  onClick: (i: number) => void;
  winningLine?: number[];
}

export function Board({ squares, onClick, winningLine = [] }: BoardProps) {
  const renderSquare = (i: number) => {
    return (
      <Square
        key={i}
        value={squares[i]}
        onClick={() => onClick(i)}
        isWinning={winningLine.includes(i)}
      />
    );
  };

  return (
    <div className="grid grid-cols-3 gap-2 w-[300px]">
      {squares.map((_, i) => renderSquare(i))}
    </div>
  );
}