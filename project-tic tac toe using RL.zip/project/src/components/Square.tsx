import React from 'react';

interface SquareProps {
  value: string;
  onClick: () => void;
  isWinning: boolean;
}

export function Square({ value, onClick, isWinning }: SquareProps) {
  return (
    <button
      className={`w-24 h-24 text-4xl font-bold ${
        isWinning
          ? 'bg-green-200 hover:bg-green-300'
          : 'bg-white hover:bg-gray-100'
      } border border-gray-300 rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500`}
      onClick={onClick}
    >
      {value}
    </button>
  );
}