// Q-learning agent for Tic Tac Toe
export class QLearningAgent {
  private qTable: Map<string, Map<number, number>>;
  private learningRate: number;
  private discountFactor: number;
  private epsilon: number;

  constructor(learningRate = 0.1, discountFactor = 0.9, epsilon = 0.1) {
    this.qTable = new Map();
    this.learningRate = learningRate;
    this.discountFactor = discountFactor;
    this.epsilon = epsilon;
  }

  private getStateKey(board: string[]): string {
    return board.join('');
  }

  private getAvailableMoves(board: string[]): number[] {
    return board
      .map((cell, index) => (cell === '' ? index : -1))
      .filter((index) => index !== -1);
  }

  private getQValues(state: string): Map<number, number> {
    if (!this.qTable.has(state)) {
      this.qTable.set(state, new Map());
    }
    return this.qTable.get(state)!;
  }

  chooseAction(board: string[]): number {
    const state = this.getStateKey(board);
    const availableMoves = this.getAvailableMoves(board);
    
    // Exploration: random move
    if (Math.random() < this.epsilon) {
      return availableMoves[Math.floor(Math.random() * availableMoves.length)];
    }

    // Exploitation: best known move
    const qValues = this.getQValues(state);
    let bestValue = -Infinity;
    let bestMoves: number[] = [];

    availableMoves.forEach(move => {
      const value = qValues.get(move) || 0;
      if (value > bestValue) {
        bestValue = value;
        bestMoves = [move];
      } else if (value === bestValue) {
        bestMoves.push(move);
      }
    });

    return bestMoves[Math.floor(Math.random() * bestMoves.length)];
  }

  learn(state: string, action: number, reward: number, nextState: string) {
    const qValues = this.getQValues(state);
    const nextQValues = this.getQValues(nextState);
    
    const currentQ = qValues.get(action) || 0;
    const nextMaxQ = Math.max(...Array.from(nextQValues.values(), v => v || 0), 0);
    
    const newQ = currentQ + this.learningRate * (reward + this.discountFactor * nextMaxQ - currentQ);
    qValues.set(action, newQ);
  }

  saveState(): string {
    return JSON.stringify(Array.from(this.qTable.entries()));
  }

  loadState(state: string) {
    this.qTable = new Map(JSON.parse(state));
  }
}